function renderMarkdownDocument(markdown, data) {
  const content = markdownToHtml(markdown);
  return wrapHtml(content, data);
}

function renderHtmlDocument(html, data) {
  return wrapHtml(html, data);
}

function wrapHtml(content, data) {
  const title = htmlEscape(data.title || data.siteName || "Blizt Site");
  const description = htmlEscape(data.description || "");
  const siteName = htmlEscape(data.siteName || "Blizt Site");
  const pageClass = htmlEscape(data.pageClass || "page");
  const navigation = data.navigation || "";
  const year = htmlEscape(data.year || "");

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${title}</title>
    <meta name="description" content="${description}">
    <link rel="stylesheet" href="/styles.css">
  </head>
  <body class="${pageClass}">
    <div class="shell">
      <header class="hero">
        <a class="brand" href="/">${siteName}</a>
        <nav class="nav">${navigation}</nav>
      </header>
      <main class="content">
${indentHtml(content, 8)}
      </main>
      <footer class="footer">
        <p>Built with Blizt. ${year}</p>
      </footer>
    </div>
  </body>
</html>
`;
}

function markdownToHtml(markdown) {
  const normalized = markdown.replace(/\r\n/g, "\n");
  const blocks = normalized.split(/\n{2,}/).map((block) => block.trim()).filter(Boolean);
  const htmlBlocks = [];

  for (const block of blocks) {
    if (block.startsWith("```") && block.endsWith("```")) {
      const lines = block.split("\n");
      const language = lines[0].slice(3).trim();
      const code = lines.slice(1, -1).join("\n");
      htmlBlocks.push(`<pre><code${language ? ` data-language="${htmlEscape(language)}"` : ""}>${htmlEscape(code)}</code></pre>`);
      continue;
    }

    if (/^- /.test(block)) {
      const items = block.split("\n").map((line) => line.replace(/^- /, "").trim());
      htmlBlocks.push(`<ul>${items.map((item) => `<li>${inlineMarkdown(item)}</li>`).join("")}</ul>`);
      continue;
    }

    if (/^#{1,6} /.test(block)) {
      const level = block.match(/^#+/)[0].length;
      const text = block.replace(/^#{1,6} /, "");
      htmlBlocks.push(`<h${level}>${inlineMarkdown(text)}</h${level}>`);
      continue;
    }

    if (/^> /.test(block)) {
      const quote = block.split("\n").map((line) => line.replace(/^> /, "")).join(" ");
      htmlBlocks.push(`<blockquote><p>${inlineMarkdown(quote)}</p></blockquote>`);
      continue;
    }

    htmlBlocks.push(`<p>${inlineMarkdown(block.replace(/\n/g, "<br>"))}</p>`);
  }

  return htmlBlocks.join("\n");
}

function inlineMarkdown(value) {
  return htmlEscape(value)
    .replace(/&lt;br&gt;/g, "<br>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`(.+?)`/g, "<code>$1</code>")
    .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2">$1</a>');
}

function indentHtml(value, spaces) {
  const padding = " ".repeat(spaces);
  return value.split("\n").map((line) => `${padding}${line}`).join("\n");
}

function htmlEscape(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function toSlug(value) {
  return String(value).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function stripExtension(fileName) {
  return fileName.replace(/\.[^.]+$/, "");
}

function replaceTokens(template, data) {
  return template.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_, key) => {
    return data[key] == null ? "" : String(data[key]);
  });
}

module.exports = {
  renderMarkdownDocument,
  renderHtmlDocument,
  toSlug,
  stripExtension,
  htmlEscape,
  replaceTokens
};
