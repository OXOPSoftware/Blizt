---
title: Home
description: Launch fast static pages with Blizt.
---
# Build a sharp site with Blizt

Blizt turns simple markdown and HTML pages into a static site in `dist`.

- Create a site with `npx blizt create`
- Build HTML with `npx blizt build`
- Serve locally on port `5000`
- Watch changes with `npx blizt watch`

## Why it feels quick

Because the engine stays tiny: your pages live in `src/pages`, your public files live in `src/public`, and the result is plain HTML.
