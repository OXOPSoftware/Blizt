---
title: About
description: Learn how Blizt structures content.
---
# About this starter

This starter is intentionally lightweight.

## Folder map

- `src/pages` contains `.md` and `.html` page files
- `src/public` copies directly into the final site
- `src/styles.css` styles every page

## Next ideas

Try adding a `contact.md` page or an `index.html` page with custom markup.
